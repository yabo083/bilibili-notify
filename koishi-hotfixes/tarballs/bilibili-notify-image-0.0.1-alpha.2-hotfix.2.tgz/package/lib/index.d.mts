import { Component, Component as Component$1, VNode, VNode as VNode$1, h } from "vue";
import { GuardLevel } from "blive-message-listener";
import * as _$vue_jsx_runtime0 from "vue/jsx-runtime";
import { Logger, ServiceContext } from "@bilibili-notify/internal";

//#region src/puppeteer.d.ts
/**
 * Platform-neutral Puppeteer abstraction. The image-engine consumes only this
 * surface; concrete adapters wrap either the koishi puppeteer service plugin
 * (koishi shell) or the npm `puppeteer` package directly (standalone runtime).
 *
 * The signatures intentionally mirror the subset of the real Puppeteer API the
 * renderer actually invokes — see `image-renderer.ts`.
 */
interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}
interface ScreenshotClip {
  x: number;
  y: number;
  width: number;
  height: number;
}
interface SetContentOptions {
  waitUntil?: "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
  timeout?: number;
}
interface WaitForFunctionOptions {
  timeout?: number;
}
interface ScreenshotOptions {
  type?: "png" | "jpeg" | "webp";
  quality?: number;
  fullPage?: boolean;
  clip?: ScreenshotClip;
}
/** Element handle returned by {@link PageLike.$}. */
interface ElementHandleLike {
  boundingBox(): Promise<BoundingBox | null>;
  dispose(): Promise<void>;
}
/** A puppeteer Page facade. Only the methods the renderer needs are exposed. */
interface PageLike {
  setContent(html: string, options?: SetContentOptions): Promise<void>;
  waitForFunction(pageFunction: string | ((...args: any[]) => unknown), options?: WaitForFunctionOptions): Promise<unknown>;
  $(selector: string): Promise<ElementHandleLike | null>;
  screenshot(options?: ScreenshotOptions): Promise<Buffer | Uint8Array>;
  close(): Promise<void>;
}
/** Puppeteer service facade. `page()` returns a fresh, disposable page each call. */
interface PuppeteerLike {
  page(): Promise<PageLike>;
}
//#endregion
//#region src/types.d.ts
type Dynamic = {
  basic: object;
  id_str: string;
  modules: {
    module_author: {
      avatar: object;
      decorate?: {
        card_url: string;
        fan: {
          num_str: number;
          color: string;
        };
      };
      face: string;
      face_nft: boolean;
      following: boolean;
      jump_url: string;
      label: string;
      mid: number;
      name: string;
      pub_action: string;
      pub_action_text: string;
      pub_location_text: string;
      pub_time: string;
      pub_ts: number;
      type: string;
      vip: {
        type: number;
      };
    };
    module_dynamic: {
      additional?: any;
      desc?: {
        rich_text_nodes: RichTextNode;
        text: string;
      };
      major?: {
        opus?: {
          fold_action: string[];
          jump_url: string;
          pics?: Array<{
            height: number;
            url: string;
            width: number;
            size: number;
            live_url: string;
          }>;
          summary?: {
            rich_text_nodes: RichTextNode;
            text: string;
          };
          title?: string;
        };
        archive?: {
          badge: {
            text: string;
          };
          cover: string;
          duration_text: string;
          title: string;
          desc: string;
          stat: {
            play: number;
            danmaku: number;
          };
          bvid: string;
          jump_url: string;
        };
        draw?: any;
        type: string;
      };
      topic?: any;
    };
    module_stat: {
      comment: {
        count: number;
      };
      forward: {
        count: number;
      };
      like: {
        count: number;
      };
    };
  };
  orig?: Dynamic;
  type: string;
  visible: boolean;
};
type RichTextNode = Array<{
  emoji?: {
    icon_url: string;
    size: number;
    text: string;
    type: number;
  };
  orig_text: string;
  text: string;
  type: string;
}>;
type LiveData = {
  watchedNum?: string | number;
  likedNum?: string | number;
  fansNum?: string | number;
  fansChanged?: string | number;
};
type CardColorOptions = {
  cardColorStart?: string;
  cardColorEnd?: string;
};
//#endregion
//#region src/image-renderer.d.ts
/**
 * Runtime configuration for {@link ImageRenderer}. Mirrors the platform-neutral
 * subset of the original koishi `BilibiliNotifyImageConfig` schema; the koishi
 * shell maps its schema fields onto this struct, and the standalone runtime
 * fills it from its own config store. The `logLevel` field is intentionally
 * dropped — the adapter is responsible for setting the logger level externally.
 */
interface ImageRendererConfig {
  /** 卡片渐变背景起始颜色（十六进制）。 */
  cardColorStart: string;
  /** 卡片渐变背景结束颜色（十六进制）。 */
  cardColorEnd: string;
  /** CSS font-family，默认值由 adapter 提供(通常透传 `DEFAULT_CARD_STYLE.font`)。 */
  font: string;
  /** 是否隐藏直播间简介。 */
  hideDesc: boolean;
  /** 是否在卡片上隐藏粉丝变化与累计观看数(对齐 `hideDesc` 命名,「隐藏=true」)。 */
  hideFollower: boolean;
}
interface ImageRendererOptions {
  serviceCtx: ServiceContext;
  puppeteer: PuppeteerLike;
  config: ImageRendererConfig;
}
declare class ImageRenderer {
  readonly logger: Logger;
  private readonly serviceCtx;
  private readonly puppeteer;
  private config;
  private readonly imageCache;
  private clearCacheTimer?;
  private readonly CACHE_TTL_MS;
  private readonly CACHE_MAX_SIZE;
  /**
   * IM1(SSRF):待内联的图片 URL 来自 B 站 API 的**不可信**字段(face /
   * cover / pics / decorate)。仅放行 B 站自有资产域 —— 任何 IP 字面量
   * (含 169.254.169.254 元数据 / 127.* / 10.* / 192.168.*)与外部域都不满足
   * 后缀匹配,天然被拒(无需 DNS 解析、无重绑定旁路)。
   */
  private static readonly IMG_HOST_ALLOWLIST;
  /** 1x1 透明 GIF —— 被拦截的远端图替换成它,保证最终 HTML 无任何外部引用可被 puppeteer 再抓。 */
  private static readonly BLOCKED_IMG_PLACEHOLDER;
  /** IM2:单张远端图字节上限,防超大图全量入内存 + base64 膨胀驻留 cache → OOM。 */
  private readonly MAX_REMOTE_IMG_BYTES;
  private renderQueue;
  constructor(opts: ImageRendererOptions);
  start(): void;
  /**
   * 热更运行时配置(卡片配色 / 字体 / 显示选项)。adapter 在 dashboard 编辑后调用,
   * 后续渲染的卡片立刻用新配色,无需重启 server。
   * 注意:已缓存的 base64 图(头像 / 封面)与配色无关,无需 invalidate。
   */
  updateConfig(config: ImageRendererConfig): void;
  stop(): void;
  numberToStr(num: number): string;
  unixTimestampToString(timestamp: number): string;
  getTimeDifference(dateString: string): Promise<string>;
  getLiveStatus(time: string, liveStatus: number): Promise<[string, string, boolean]>;
  generateLiveCard(data: any, username: string, userface: string, liveData: LiveData, liveStatus: number, colorOptions?: CardColorOptions): Promise<Buffer>;
  generateGuardCard({
    guardLevel,
    uname,
    face,
    isAdmin
  }: {
    guardLevel: GuardLevel;
    uname: string;
    face: string;
    isAdmin: number;
  }, {
    masterAvatarUrl,
    masterName
  }: {
    masterAvatarUrl: string;
    masterName: string;
  }): Promise<Buffer>;
  generateSCCard({
    senderFace,
    senderName,
    masterName,
    text,
    price,
    masterAvatarUrl
  }: {
    senderFace: string;
    senderName: string;
    masterName: string;
    text: string;
    price: number;
    masterAvatarUrl?: string;
  }): Promise<Buffer>;
  generateDynamicCard(data: Dynamic, colorOptions?: CardColorOptions): Promise<Buffer>;
  generateWordCloudImg(words: Array<[string, number]>, masterName: string, masterAvatarUrl?: string): Promise<Buffer>;
  private isRemoteUrl;
  /**
   * IM1:SSRF 白名单闸门。仅 http(s) + B 站自有资产域后缀。任何 IP 字面量 /
   * 内网主机 / 外部域都不匹配 → 拒绝。被拒 URL 既不由本进程 fetch,也会在
   * {@link inlineRemoteImages} 里被透明占位替换,使 puppeteer 同样无从抓取。
   */
  private isFetchAllowed;
  private getMimeType;
  private pruneImageCache;
  private fetchImageAsDataUrl;
  /** IM2:流式读取并在累计字节超 {@link MAX_REMOTE_IMG_BYTES} 时 abort 熔断。 */
  private readCapped;
  /** 按批次限制并发数量，避免同时发起过多请求 */
  private fetchWithConcurrencyLimit;
  /** 将 HTML 中所有远程图片和 CSS 背景替换为 base64 data URL，避免渲染时跨域 */
  private inlineRemoteImages;
  private doRender;
  /** 将渲染任务加入串行队列 */
  private renderHtml;
}
//#endregion
//#region src/render.d.ts
declare function renderCard(component: Component$1, props: Record<string, unknown>, options?: {
  title?: string;
  font?: string;
  htmlWidth?: number;
}): Promise<string>;
//#endregion
//#region src/templates/dynamic-card.d.ts
type DynamicCardProps = {
  cardColorStart: string;
  cardColorEnd: string;
  decorateColor: string;
  avatarUrl: string;
  upName: string;
  upIsVip: boolean;
  pubTime: string;
  decorateCardUrl?: string;
  decorateCardId?: string;
  topic?: string;
  mainContent: VNode$1;
  forwardCount: string;
  commentCount: string;
  likeCount: string;
};
declare function DynamicCard(p: DynamicCardProps): _$vue_jsx_runtime0.JSX.Element;
//#endregion
//#region src/templates/guard-card.d.ts
type GuardCardProps = {
  captainImgUrl: string;
  guardLevel: GuardLevel;
  uname: string;
  face: string;
  isAdmin: number;
  masterAvatarUrl: string;
  masterName: string;
  bgColor: [string, string];
};
declare function GuardCard(p: GuardCardProps): _$vue_jsx_runtime0.JSX.Element;
//#endregion
//#region src/templates/live-card.d.ts
/** @jsxImportSource vue */
type LiveCardProps = {
  hideDesc: boolean; /** 隐藏粉丝变化 / 累计观看数(对齐 hideDesc 命名;隐藏=true)。 */
  hideFollower: boolean;
  cardColorStart: string;
  cardColorEnd: string;
  data: any;
  username: string;
  userface: string;
  titleStatus: string;
  liveTime: string;
  liveStatus: number;
  cover: boolean;
  onlineNum: string;
  likedNum: string;
  watchedNum: string;
  fansNum: string;
  fansChanged: string;
};
declare function LiveCard(p: LiveCardProps): _$vue_jsx_runtime0.JSX.Element;
//#endregion
//#region src/templates/sc-card.d.ts
type SCCardProps = {
  senderFace: string;
  senderName: string;
  masterName: string;
  masterAvatarUrl?: string;
  text: string;
  price: number;
  duration: string;
  bgColor: readonly [string, string];
};
declare function SCCard(p: SCCardProps): _$vue_jsx_runtime0.JSX.Element;
//#endregion
export { type BoundingBox, type CardColorOptions, type Component, type Dynamic, DynamicCard, type DynamicCardProps, type ElementHandleLike, GuardCard, type GuardCardProps, ImageRenderer, type ImageRendererConfig, type ImageRendererOptions, LiveCard, type LiveCardProps, type LiveData, type PageLike, type PuppeteerLike, type RichTextNode, SCCard, type SCCardProps, type ScreenshotClip, type ScreenshotOptions, type SetContentOptions, type VNode, type WaitForFunctionOptions, h, renderCard };