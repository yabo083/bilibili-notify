import { DeliveryResult, FeatureKey, GlobalDefaults, Logger, NotificationPayload, NotificationSink, PushTarget, ServiceContext } from "@bilibili-notify/internal";
import { SubscriptionStore } from "@bilibili-notify/subscription";

//#region src/bilibili-push.d.ts
/**
 * Per-send context fired after每条 `sendToTarget` 结束(成功/失败均触发)。Adapter
 * 用它把 history 记录里的 `uid` 与 `source` 拼对 —— multiplex sink 拿不到
 * 这两个字段(它只看 PushTarget),所以历史只能从这一层注入。
 */
interface PushSendInfo {
  uid: string;
  feature: FeatureKey | "private";
  target: PushTarget;
  payload: NotificationPayload;
  result: DeliveryResult;
  private: boolean;
}
/** Options for constructing a BilibiliPush instance. */
interface BilibiliPushOptions {
  /** Platform-neutral push sink — translates targetId → platform delivery. */
  sink: NotificationSink;
  /** Subscription store — used to resolve routing per uid+feature. */
  store: SubscriptionStore;
  /** Optional master PushTarget for private error notifications. */
  master?: PushTarget | null;
  /** Logger instance. */
  logger: Logger;
  /**
   * 可选 ServiceContext。传入后,retry backoff 的 sleep 走 `serviceCtx.setTimeout`,
   * plugin/runtime dispose 时可被立即 clear,不会留 32s 空跑 timer。stop() 也会
   * 唤醒所有 sleeping retry 循环立即收敛。
   *
   * 不传则退化为裸 setTimeout + stop() 唤醒(过渡期兼容,仍能 dispose-safe)。
   */
  serviceCtx?: ServiceContext;
  /**
   * Latest `GlobalDefaults` provider — used to resolve `EffectiveSubscription`
   * per push so `features.X` and `schedule.quietHours` gates work against the
   * current globals state (not a stale snapshot).
   *
   * 可选:若不传,broadcastToFeature 退化为「仅 routing 决定是否发」的旧行为,
   * 用于过渡期的 Koishi adapter 还没接 globals 的场景。
   */
  defaults?: () => GlobalDefaults;
  /**
   * Optional hook fired after every successful or failed send. Receives the
   * resolved `target` plus the originating `uid` / `feature` — fields the
   * multiplex sink can't see. Standalone wires this to history-store append.
   */
  onSend?: (info: PushSendInfo) => void;
}
/**
 * Platform-neutral push router.
 *
 * Replaces the old koishi-coupled BilibiliPush. Routing comes from
 * store.findByUid(uid)?.routing[feature] → targetId[] → sink.send(targetId, payload).
 * The old pushArrMap, broadcastToTargets, sendPrivateMsg/sendErrorMsg are gone.
 */
declare class BilibiliPush {
  private readonly sink;
  private readonly store;
  private master;
  /**
   * 边沿触发用:master 上次已知可达性。`undefined`=未评估;`true/false`=上次判定。
   * 仅在跳变时打日志(见 {@link refreshMasterReachability}),避免持续不可达时
   * 在 per-tick 热路径刷 error(Q1 约束)。
   */
  private masterReachable?;
  private readonly logger;
  private readonly defaults?;
  private readonly onSend?;
  private readonly serviceCtx?;
  private disposed;
  /**
   * Per-lifecycle generation token。每次 `start()` 自增;in-flight retry 循环
   * 进入时快照本代号,循环条件附加 `generation === myGen`。这样 stop()→start()
   * 快速重启时,上一生命周期遗留的 in-flight 重试循环(可能正卡在 sleep)被
   * 唤醒后会因代号不符立即退出,不会"复活"到新生命周期上重发([both]/Codex-P1)。
   */
  private generation;
  /**
   * 正在 sleep 等重试的 wake 函数集合 — `stop()` 时全部触发立即返回,避免裸 setTimeout
   * 路径下 retry 循环卡到 32s 才退出。
   */
  private readonly sleepWakers;
  constructor(opts: BilibiliPushOptions);
  /**
   * 热替换 master PushTarget。adapter 在 globals/targets 变化后调用,
   * 后续 `sendPrivateMsg` / `sendErrorMsg` 立即用新目标。
   * `null` 表示"无 master 配置",私聊路径变 no-op。
   */
  setMaster(target: PushTarget | null): void;
  /**
   * 边沿触发 master 可达性日志。available→unreachable 跳变(含首次未知→不可达)
   * 报一次 `error`(告警背channel已断,运维必须立刻知道);unreachable→available
   * 报一次 `info`;持续不可达不再刷(由调用方各自 `debug` 记录跳过)。同时满足
   * "运维必须立刻知道" 与 Q1 "error 不得在 per-tick/per-retry 热路径刷" 两约束。
   */
  private refreshMasterReachability;
  start(): void;
  stop(): void;
  /**
   * Broadcast a notification to all targets registered for a given uid + feature.
   * Returns an array of DeliveryResult (one per target).
   *
   * @全体成员 修饰(仅 `feature === "dynamic" | "live"` 且 `opts.allowAtAll !== false` 进入):
   * - 订阅级默认 `sub.atAllDefaults.X` 决定 inherit-state 的 target 是否 @
   * - per-target tristate Map `sub.atAll.X[targetId]` 显式覆写:`true` 强 ON、`false` 强 OFF
   * - Map 里没有该 key → 走默认
   *
   * `feature === "live"` 仅作用于开播。但 live adapter 把「开播」和周期「正在直播」
   * 复推都翻译成 `feature === "live"`(routing/总开关共用 live,模型里没有独立的
   * ongoing key),仅靠 feature 无法区分。调用方据 `LivePushType` 判定:非开播的
   * live 推送(周期 ongoing 等)必须传 `opts.allowAtAll = false` 显式抑制 @全体,
   * 否则会每条直播推送都 @全体(本次修复的 bug)。SC/上舰/词云/总结/下播 走它们
   * 自己的 feature key,本就不进 atAll 分支,传不传 allowAtAll 无影响。不传 opts
   * = 保持「feature 决定」的旧行为(dynamic 调用点据此不变)。
   */
  broadcastToFeature(uid: string, feature: FeatureKey, payload: NotificationPayload, opts?: {
    allowAtAll?: boolean;
  }): Promise<DeliveryResult[]>;
  /**
   * Send a notification to all targets in the list.
   * Failures are captured per-target; does not throw.
   * Optional `ctx` carries the originating uid/feature so adapter hooks
   * (history append) get the correct fields. broadcastToFeature passes ctx;
   * legacy callers without ctx get history rows with empty uid.
   */
  sendBatch(targetIds: string[], payload: NotificationPayload, ctx?: {
    uid: string;
    feature: FeatureKey | "private";
  }): Promise<DeliveryResult[]>;
  /**
   * Send a notification to a single target.
   * Retries with exponential back-off if the sink indicates the target is temporarily unavailable.
   */
  sendToTarget(targetId: string, payload: NotificationPayload, opts?: {
    private?: boolean;
  }): Promise<DeliveryResult>;
  /**
   * Send a private message to the configured master target.
   * No-op if no master is configured or target is unavailable.
   */
  sendToMaster(payload: NotificationPayload): Promise<DeliveryResult | null>;
  /** Convenience: send a plain-text error message to the master. */
  sendPrivateMsg(text: string): Promise<void>;
  /** Convenience: log the error and optionally notify master. */
  sendErrorMsg(reason: string): Promise<void>;
  private sleep;
}
//#endregion
export { BilibiliPush, type BilibiliPushOptions };