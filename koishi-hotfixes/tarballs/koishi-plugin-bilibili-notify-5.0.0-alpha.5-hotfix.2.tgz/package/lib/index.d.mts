import { DataService } from "@koishijs/plugin-console";
import { CookieData, StorageManager } from "@bilibili-notify/storage";
import { Awaitable, Context, Schema, Service, Session } from "koishi";
import { PushAdapter, PushTarget, Subscription, SubscriptionOp, SubscriptionOp as SubscriptionOp$1 } from "@bilibili-notify/internal";
import * as _$_bilibili_notify_api0 from "@bilibili-notify/api";
import { BiliDataServer, BilibiliAPI, LoginFlow } from "@bilibili-notify/api";
import { BilibiliPush } from "@bilibili-notify/push";
import { FlatSubConfigItem, SubscriptionStore } from "@bilibili-notify/subscription";

//#region src/config.d.ts
/** 免打扰时段:落进任一区间内的推送直接丢弃,粒度按「时」,半开区间 [start, end)。 */
interface KoishiQuietHourRange {
  start: number;
  end: number;
}
interface BilibiliNotifyConfig {
  advancedSub: boolean;
  subs: FlatSubConfigItem[];
  logLevel: number;
  userAgent?: string;
  loginHealthCheckMinutes: number;
  master: {
    enable: boolean;
    platform?: string;
    masterAccount?: string;
    masterAccountGuildId?: string;
  };
  /**
   * 全局免打扰时段。per-UP 不自定义则继承本字段;per-UP 在 advanced-subscription
   * schema 里可以单独配 quietHours 覆盖。
   *
   * features 总开关之所以不在 koishi config 暴露,是因为 koishi 端添加新订阅时
   * 已经由 advanced-subscription / subs[] 的 Schema.boolean().default(true) 提供
   * 默认值——「全局 features 默认值」这个语义在 koishi 端冗余;它只对 dashboard
   * 的「添加新订阅时的初始勾选」流程有意义。
   */
  quietHours?: KoishiQuietHourRange[];
}
declare const BilibiliNotifyConfigSchema: Schema<BilibiliNotifyConfig>;
//#endregion
//#region src/target-registry.d.ts
/**
 * Simple in-memory adapter+target registry for the koishi side.
 * The standalone side uses ConfigStore; the koishi side synthesizes adapters
 * and targets from the legacy flat config and holds them here.
 */
declare class TargetRegistry {
  private readonly adapters;
  private readonly targets;
  get(id: string): PushTarget | undefined;
  set(target: PushTarget): void;
  delete(id: string): void;
  all(): PushTarget[];
  setAdapter(adapter: PushAdapter): void;
  getAdapter(id: string): PushAdapter | undefined;
  allAdapters(): PushAdapter[];
  /** Find an existing koishi-bot adapter matching the (botPlatform, selfId?) pair. */
  findKoishiBotAdapter(botPlatform: string, selfId?: string): PushAdapter | undefined;
  /** Find a koishi-bot target on a given adapter + channel. */
  findTargetByChannel(adapterId: string, channelId: string): PushTarget | undefined;
  clear(): void;
}
//#endregion
//#region src/lifecycle.d.ts
/** Shape returned by `BilibiliNotifyServerManager.getInternals(BILIBILI_NOTIFY_TOKEN)`. */
interface InternalsShape {
  api: BilibiliAPI;
  push: BilibiliPush;
  store: SubscriptionStore;
  /**
   * Koishi-side PushTarget registry. Friendly plugins (e.g. AI tools that
   * create subscriptions on the user's behalf) need this to resolve a real
   * targetId to wire into `Subscription.routing` instead of inventing a
   * random UUID that points at no target.
   */
  registry: TargetRegistry;
}
//#endregion
//#region src/app-bootstrap.d.ts
/**
 * Koishi `Service` shell. Owns the controllers (auth, subscriptions, health,
 * master-notifier) and the runtime singletons (api / push / storage). The
 * external surface (`getInternals(token)`, `subList()`, `getAuthSnapshot()`)
 * preserves what commands, data-server, and downstream sub-plugins consume.
 */
declare class BilibiliNotifyServerManager extends Service<BilibiliNotifyConfig> {
  static readonly [Service.provide] = "bilibili-notify";
  private readonly serverLogger;
  private readonly selfCtx;
  private readonly slots;
  private running;
  storageMgr: StorageManager;
  private masterNotifier;
  constructor(ctx: Context, config: BilibiliNotifyConfig);
  private get api();
  private get push();
  private get loginBridge();
  get store(): SubscriptionStore | null;
  getAuthSnapshot(): _$_bilibili_notify_api0.BiliDataServer;
  validateQrLoginSession(session?: Session): string | undefined;
  beginQrLogin(): Promise<_$_bilibili_notify_api0.BiliDataServer>;
  subList(): string;
  protected start(): Promise<void>;
  protected stop(): Awaitable<void>;
  /**
   * 向持有 BILIBILI_NOTIFY_TOKEN 的友好插件暴露 api / push / store 实例。
   * token 用于防误调；Koishi 同进程插件没有安全隔离,这里不把它当安全边界。
   */
  getInternals(token: symbol): InternalsShape | null;
  registerPlugin(): Promise<boolean>;
  disposePlugin(): boolean;
  restartPlugin(): Promise<boolean>;
  private initStorage;
  private initControllers;
  private wireCookiePersistence;
}
//#endregion
//#region src/data-server.d.ts
declare class BilibiliNotifyDataServer extends DataService<BiliDataServer> {
  private biliData;
  constructor(ctx: Context);
  get(): Promise<BiliDataServer>;
}
//#endregion
//#region src/index.d.ts
declare module "koishi" {
  interface Context {
    "bilibili-notify": BilibiliNotifyServerManager;
  }
  interface Events {
    "bilibili-notify/login-status-report"(data: BiliDataServer): void;
    "bilibili-notify/auth-lost"(): void;
    "bilibili-notify/auth-restored"(): void;
    "bilibili-notify/advanced-sub"(subs: Subscription[]): void;
    /**
     * Emitted by the advanced-subscription adapter ahead of `advanced-sub`.
     * Carries the synthesized PushTarget list for every channel that any
     * sub references, so the koishi-side TargetRegistry can register them
     * before the routing payloads land. Without this the targetIds embedded
     * in routing point at no PushTarget and the push routing silently drops
     * the message (Fix 6).
     */
    "bilibili-notify/advanced-sub-targets"(targets: PushTarget[]): void;
    /**
     * Emitted ahead of `advanced-sub-targets`. Carries the koishi-bot
     * adapters that targets reference; the registry must have them before
     * `assertAdapterMatches`-style validation runs.
     */
    "bilibili-notify/advanced-sub-adapters"(adapters: PushAdapter[]): void;
    "bilibili-notify/ready-to-receive"(): void;
    "bilibili-notify/cookies-refreshed"(data: CookieData): void;
    "bilibili-notify/subscription-changed"(ops: SubscriptionOp$1[]): void;
    "bilibili-notify/ready"(api: BilibiliAPI): void;
    "bilibili-notify/engine-error"(source: string, message: string): void;
    "bilibili-notify/update-config"(config: BilibiliNotifyConfig): void;
  }
}
declare module "@koishijs/plugin-console" {
  namespace Console {
    interface Services {
      "bilibili-notify": BilibiliNotifyDataServer;
    }
  }
  interface Events {
    "bilibili-notify/start-login"(): void;
    "bilibili-notify/reset-key"(): void;
    "bilibili-notify/request-cors"(url: string): any;
  }
}
declare const inject: {
  required: string[];
  optional: string[];
};
declare const name = "bilibili-notify";
declare const usage = "\n<h1>Bilibili-Notify</h1>\n<p>\u4F7F\u7528\u95EE\u9898\u8BF7\u52A0\u7FA4\u54A8\u8BE2 801338523</p>\n\n---\n\n\u4E3B\u4EBA\u597D\u5440\uFF5E\u6211\u662F\u7B28\u7B28\u5973\u4EC6\u5C0F\u52A9\u624B\u54D2 (\u3003\u2200\u3003)\u2661\n\u4E13\u95E8\u5E2E\u4E3B\u4EBA\u7BA1\u7406 B \u7AD9\u8BA2\u9605\u548C\u76F4\u64AD\u63A8\u9001\u7684\uFF01\n\u5973\u4EC6\u867D\u7136\u7B28\u7B28\u7684\uFF0C\u4F46\u662F\u4F1A\u5C3D\u529B\u4E0D\u51FA\u9519\u54E6\uFF5E\n\u4E3B\u4EBA\uFF0C\u53EA\u8981\u6309\u7167\u5973\u4EC6\u7684\u63D0\u793A\u4E00\u6B65\u4E00\u6B65\u8BBE\u7F6E\uFF0C\u5973\u4EC6\u5C31\u53EF\u4EE5\u4E56\u4E56\u5E2E\u60A8\u5DE5\u4F5C\u5566\uFF01\n\n\u9996\u5148\u5462\uFF5E\u8BF7\u4E3B\u4EBA\u4ED4\u7EC6\u9605\u8BFB\u8BA2\u9605\u76F8\u5173\u7684 subs \u7684\u586B\u5199\u8BF4\u660E (>\u03C9<)b\n\u3010\u4E3B\u4EBA\u8D26\u53F7\u90E8\u5206\u975E\u5FC5\u586B\u3011\u7136\u540E\u518D\u544A\u8BC9\u5973\u4EC6\u60A8\u7684 \u4E3B\u4EBA\u8D26\u53F7 (///\u25BD///)\uFF0C\u5E76\u9009\u62E9\u60A8\u5E0C\u671B\u5973\u4EC6\u670D\u52A1\u7684\u5E73\u53F0\uFF5E\n\u63A5\u7740\uFF0C\u8BF7\u8BA4\u771F\u586B\u5199 \u4E3B\u4EBA\u7684 ID \u548C \u7FA4\u7EC4 ID\uFF0C\u786E\u4FDD\u4FE1\u606F\u5B8C\u5168\u6B63\u786E\uFF5E\n\u8FD9\u6837\u5973\u4EC6\u624D\u80FD\u987A\u5229\u627E\u5230\u60A8\u5E76\u51C6\u786E\u6C47\u62A5\u52A8\u6001\u5462 (\u2267\u25BD\u2266)\n\n\u4E0D\u7528\u7740\u6025\uFF0C\u5973\u4EC6\u4F1A\u4E00\u76F4\u5728\u8FD9\u91CC\u966A\u7740\u60A8\uFF0C\u4E00\u6B65\u4E00\u6B65\u5B8C\u6210\u8BBE\u7F6E\uFF5E\n\u4E3B\u4EBA\u53EA\u8981\u4E56\u4E56\u586B\u597D\u8FD9\u4E9B\u4FE1\u606F\uFF0C\u5C31\u80FD\u8BA9\u5973\u4EC6\u53D8\u5F97\u8D85\u7EA7\u542C\u8BDD\u3001\u8D85\u7EA7\u52E4\u5FEB\u5566 (>///<)\u2661\n\n\u60F3\u8981\u91CD\u65B0\u767B\u5F55\u7684\u8BDD\uFF0C\u53EA\u9700\u8981\u70B9\u51FB\u63A7\u5236\u53F0\u5DE6\u4FA7\u7684\u300C\u626B\u7801\u767B\u5F55\u300D\u54E6\uFF5E\n\n\u4E3B\u4EBA\uFF5E\u6CE8\u610F\u4E8B\u9879\u8981\u4ED4\u7EC6\u770B\u5440 (>_<)\u2661\n- \u5982\u679C\u4E3B\u4EBA\u4F7F\u7528\u7684\u662F onebot \u673A\u5668\u4EBA\uFF0C\u5E73\u53F0\u540D\u8BF7\u586B\u5199 onebot\uFF0C\u800C\u4E0D\u662F qq \u54E6\uFF5E\n- \u5982\u679C\u9700\u8981\u66F4\u7075\u6D3B\u7684\u8BA2\u9605\u914D\u7F6E\uFF0C\u8BF7\u5B89\u88C5 bilibili-notify-advanced-subscription \u63D2\u4EF6\n\n\u4E56\u4E56\u9075\u5B88\u8FD9\u4E9B\u89C4\u5219\uFF0C\u5973\u4EC6\u624D\u80FD\u987A\u5229\u5E2E\u4E3B\u4EBA\u5DE5\u4F5C\u5462 (*>\u03C9<)b\n\n---\n";
declare function apply(ctx: Context, config: BilibiliNotifyConfig): void;
declare const Config: Schema<BilibiliNotifyConfig>;
//#endregion
export { type BilibiliNotifyConfig, BilibiliNotifyConfigSchema, Config, type SubscriptionOp as LegacySubscriptionOp, type SubscriptionOp$1 as SubscriptionOp, apply, inject, name, usage };
