import { Logger, MessageBus, ServiceContext } from "@bilibili-notify/internal";
import { CookieData } from "@bilibili-notify/storage";

//#region src/types.d.ts
declare enum BiliLoginStatus {
  NOT_LOGIN = 0,
  LOADING_LOGIN_INFO = 1,
  LOGIN_QR = 2,
  LOGGING_QR = 3,
  LOGGED_IN = 5,
  LOGIN_FAILED = 7
}
interface BiliDataServer {
  status: BiliLoginStatus;
  msg: string;
  data?: any;
}
interface BiliTicket {
  code: number;
  message: string;
  data: {
    ticket: string;
    created_at: number;
    ttl: number;
    context: Record<string, unknown>;
    nav: {
      img: string;
      sub: string;
    };
  };
}
interface BACookie {
  key: string;
  value: string;
  expires?: string;
  domain?: string;
  path?: string;
  secure?: boolean;
  httpOnly?: boolean;
  sameSite?: string;
}
/**
 * B 站统一响应信封。**`data` 可为 null** —— 错误码(-101/-352/-403/-509…)常
 * 返回 `data:null` 或缺 data;把它建模为必有会诱导调用方无保护解引用(本仓多处
 * "data null" 类缺陷的共同根因)。注:各具体 *Data 接口仍各自把 data 建模为
 * 必有,收敛它们属根因级重构(跨区爆破),本轮仅收信封层 + 逐点修可达解引用。
 */
interface Result<T = unknown> {
  code: number;
  message: string;
  data: T | null;
}
interface CreateGroup {
  tagid: number;
}
interface GroupList {
  tagid: number;
  name: string;
  count: number;
  tip: string;
}
interface MySelfInfoData {
  code: number;
  data: {
    mid: number;
    uname: string;
    face: string;
  };
}
interface UserCard {
  mid: string;
  name: string;
  face: string;
  sign: string;
  attention: number;
  fans: number;
  level_info: {
    current_level: number;
  };
  official: {
    role: number;
    title: string;
    type: number;
  };
  vip: {
    type: number;
    status: number;
    vipStatus: number;
    label: {
      text: string;
      img_label_uri_hans_static: string;
    };
  };
}
interface UserCardSpace {
  s_img: string;
  l_img: string;
}
/** Body of `UserCardInfoData.data` — exported for client-side consumers. */
interface UserCardInfo {
  card: UserCard;
  space: UserCardSpace;
  like_num: number;
}
interface UserCardInfoData {
  code: number;
  data: UserCardInfo;
}
interface LiveRoomInfo {
  code: number;
  data: {
    uid: number;
    room_id: number;
    short_id: number;
    live_status: number;
    live_time: string;
    title: string;
    user_cover: string;
    keyframe: string;
    tags: string;
    area_name: string;
    parent_area_name: string;
  };
}
interface MasterInfoData {
  code: number;
  data: {
    info: {
      uid: number;
      uname: string;
      face: string;
      gender: number;
    };
    exp: {
      master_level: {
        level: number;
        color: number;
      };
    };
    follower_num: number;
    room_id: number;
    medal_name: string;
  };
}
interface V_VoucherCaptchaData {
  code: number;
  message: string;
  data: {
    type: string;
    token: string;
    geetest: {
      challenge: string;
      gt: string;
    };
    tencent: unknown;
  };
}
interface ValidateCaptchaData {
  code: number;
  message: string;
  data: {
    grisk_id: string;
    mobile_verify: boolean;
    success_type: number;
  } | null;
}
//#endregion
//#region src/bilibili-api.d.ts
interface CookiesRefreshedPayload {
  cookiesJson: string;
  refreshToken: string;
}
interface BilibiliAPICallbacks {
  /**
   * Persist refreshed cookies. May be async — the refresh path `await`s it and
   * loudly logs a reject (in-memory jar is already updated; only disk lagged),
   * instead of the old `void`-typed fire-and-forget that let a persistence
   * failure pass as a successful refresh with an unhandled rejection.
   */
  onCookiesRefreshed?: (payload: CookiesRefreshedPayload) => Promise<void> | void;
  /** Fired when the upstream returns code -101 (session invalid). Debounced 60s. */
  onAuthLost?: () => void;
}
interface BilibiliAPIConfig {
  userAgent?: string;
}
interface BilibiliAPIOptions {
  serviceCtx: ServiceContext;
  config: BilibiliAPIConfig;
  callbacks?: BilibiliAPICallbacks;
}
declare class BilibiliAPI {
  readonly logger: Logger;
  private readonly serviceCtx;
  private config;
  private readonly callbacks;
  private jar;
  private client;
  private wbiKeys;
  private ticketJob;
  private refreshCookieTimer?;
  private loginInfoLoaded;
  private authLostFiredAt;
  /**
   * Bumped on every event that supersedes the cookie state a refresh was
   * started against (loadCookies re-entry / clearCookies / -101 reset). An
   * in-flight `checkIfTokenNeedRefresh` captures the value at entry and aborts
   * before applying side effects if it changed — otherwise a slow refresh from
   * a previous login lands late and `onCookiesRefreshed` overwrites the new
   * session's cookies with stale ones.
   */
  private refreshGeneration;
  /** Single-in-flight guard so the hourly timer + loadCookies don't run the RSA dance concurrently. */
  private refreshInFlight;
  /**
   * BiliTicket 在途去重。并发签名(或 wbiGet -352 清空 wbiKeys 后多个并行
   * 重试)会各自触发一次 ticket POST 风暴;共享同一在途 Promise 收敛为一次。
   */
  private biliTicketInFlight?;
  constructor(opts: BilibiliAPIOptions);
  start(): Promise<void>;
  stop(): void;
  /**
   * 热替换 User-Agent。adapter 在 dashboard 编辑 `app.userAgent` 后调用,
   * 直接改 axios 实例的 default headers,后续请求生效;已 in-flight 的请求
   * 仍走旧 UA。`undefined` / 空串 → 回退到内置默认 Firefox UA。
   */
  setUserAgent(userAgent: string | undefined): void;
  private initClient;
  /**
   * Response-interceptor path: only `-101` (session invalid) from an arbitrary
   * endpoint counts as auth-lost. `-352` etc. seen here are transient
   * risk-control on data endpoints, NOT session death — must not widen this
   * gate or every throttled data call would spuriously log the user out.
   */
  private maybeFireAuthLost;
  /**
   * Debounced `onAuthLost` dispatch (60s). The caller has already decided the
   * state is terminal — either interceptor `-101`, or a failed cookie-refresh
   * chain (the authoritative session-liveness check; if it can't refresh, the
   * session is unrecoverable and the user must re-scan).
   */
  private fireAuthLost;
  /**
   * 会话终态清理 —— `-101`(B1)/ B2 终态码 / confirm 终态码 共用。②3:此前
   * 仅 B1 做了 timer dispose + loginInfoLoaded 清理,B2/confirm 只 emit 没清,
   * 死会话每小时继续 RSA 轮换、isLoginInfoLoaded 仍误报已登录。收敛到一处。
   */
  private terminateSession;
  addCookie(cookieStr: string): void;
  private addLoginCookiesFromUrl;
  private completeLoginCookies;
  getCookiesJson(): string | undefined;
  getCookiesHeader(): string;
  private getCSRF;
  /** Load cookies from CookieData (decrypted by StorageManager) */
  loadCookies(data: CookieData): Promise<void>;
  /**
   * Guarded fire-and-forget entry to {@link checkIfTokenNeedRefresh} used by
   * the two internal triggers (loadCookies / hourly timer). Skips if a refresh
   * is already running so the RSA/correspond/confirm dance never overlaps.
   */
  private triggerRefreshCheck;
  markLoginInfoLoaded(): void;
  isLoginInfoLoaded(): boolean;
  /**
   * 清空内存 cookie jar(登出 / 密钥重置)。调用方此前只删盘 cookie 而不清
   * 这里,导致 api 仍以 stale SESSDATA/bili_jct 发已认证请求,直到进程重启
   * (安全缺陷,P0-2)。重建 jar + 重绑 client(沿用 -101 路径同款做法,
   * 旧 client 仍持旧 jar 引用,必须 initClient 重绑),停掉刷新定时器
   * (登出后已无 refreshToken 可刷),标记未登录。
   */
  clearCookies(): Promise<void>;
  private parseExpires;
  private enableRefreshCookiesInterval;
  checkIfTokenNeedRefresh(refreshToken: string, csrf: string, gen?: number): Promise<void>;
  private updateBiliTicket;
  private doUpdateBiliTicket;
  private getBiliTicket;
  private getWbi;
  /**
   * WBI 签名 GET。B3:`getWbi` 仅在 imgKey 为空时才刷新 key,服务端轮换 WBI
   * 后既有 key 仍非空 → 所有签名请求一路 `-352` 直到午夜 ticket cron。这里在
   * 响应 `code === -352` 时清空 wbiKeys 强制重取 ticket,并重试一次。
   */
  private wbiGet;
  private retry;
  getAllDynamic(): Promise<any>;
  getUserSpaceDynamic(mid: string): Promise<any>;
  hasNewDynamic(updateBaseline: string): Promise<any>;
  getLoginQRCode(): Promise<any>;
  getLoginStatus(qrcodeKey: string): Promise<any>;
  getMyselfInfo(): Promise<MySelfInfoData>;
  getMyselfInfoCached(): Promise<MySelfInfoData>;
  getUserCardInfo(mid: string, withPhoto?: boolean): Promise<UserCardInfoData>;
  getUserInfo(mid: string, griskId?: string): Promise<any>;
  getLiveRoomInfo(roomId: string): Promise<LiveRoomInfo>;
  getMasterInfo(uid: string): Promise<MasterInfoData>;
  getLiveRoomInfoStreamKey(roomId: string): Promise<any>;
  getLiveRoomInfoByUids(uids: string[]): Promise<any>;
  getOnlineGoldRank(roomId: string, ruid: string, page?: number, pageSize?: number): Promise<any>;
  getUserInfoInLive(uid: string, ruid: string): Promise<any>;
  getTheUserWhoIsLiveStreaming(): Promise<any>;
  getUserUpstat(mid: string): Promise<any>;
  getUserNavnum(mid: string): Promise<any>;
  getUserVideos(mid: string, ps?: number): Promise<any>;
  searchByType(searchType: string, keyword: string, opts?: {
    page?: number;
    pageSize?: number;
  }): Promise<any>;
  /**
   * 查询"cookie 是否需要刷新"。该端点的 `csrf` 参数语义是 **bili_jct**(非
   * refresh_token);此前误传 refreshToken,虽然该读接口靠 SESSDATA 鉴权、
   * csrf 可选,传错多被服务端忽略,但与官方契约不符且一旦服务端开始校验
   * 该参数即会整条刷新探测失效。统一传真实 bili_jct csrf。
   */
  getCookieInfo(csrf: string): Promise<any>;
  follow(fid: string): Promise<any>;
  createGroup(tag: string): Promise<any>;
  getAllGroup(): Promise<any>;
  copyUserToGroup(mid: string, groupId: string): Promise<any>;
  getRelationGroupDetail(tagid: string): Promise<any>;
  v_voucherCaptcha(v_voucher: string): Promise<V_VoucherCaptchaData["data"]>;
  validateCaptcha(challenge: string, token: string, validate: string, seccode: string): Promise<ValidateCaptchaData["data"] | null>;
}
//#endregion
//#region src/login-flow.d.ts
/** Reason keys driving the user-facing message in a snapshot transition. */
type LoginStatusMsgKey = "loading" | "notLogin" | "keyReset" | "authLost" | "loggedIn" | "loginJustSucceeded" | "fetchAccountFailed" | "waitScan" | "waitConfirm" | "qrFetchFailed" | "qrRenderFailed" | "qrExpired" | "qrInvalidated" | "noCookieAfterLogin" | "genericLoginFail";
/** Snapshot of the current login state — alias of BiliDataServer for API consumers. */
type LoginSnapshot = BiliDataServer;
/** Outcome of a single QR poll tick. The bridge does not need to act on this directly. */
type LoginPollResult = {
  kind: "pending";
  reason: "waitScan" | "waitConfirm";
} | {
  kind: "success";
} | {
  kind: "failed";
  reason: LoginStatusMsgKey;
};
interface LoginFlowOptions {
  serviceCtx: ServiceContext;
  api: BilibiliAPI;
  bus: MessageBus;
  /** Periodic auth probe cadence in ms. 0 disables the heartbeat. */
  healthCheckMs: number;
  /** Persist refreshed/just-issued cookies. Called by the post-login handshake. */
  saveCookies: (data: CookieData) => Promise<void>;
}
declare class LoginFlow {
  private readonly serviceCtx;
  private readonly api;
  private readonly bus;
  private healthCheckMs;
  private readonly saveCookies;
  private readonly logger;
  private snapshot;
  private healthTimer?;
  private loginTimer?;
  private loginExpiryTimer?;
  /**
   * Marks "we were once logged in but transitioned out". On the next successful login the flag
   * is flipped and `auth-restored` fires. Avoids relying on the previous frame's status, which
   * would miss the path NOT_LOGIN → LOGIN_QR → LOGGING_QR → LOGGED_IN.
   */
  private needsRestore;
  constructor(opts: LoginFlowOptions);
  /** Lifecycle hook for adapter symmetry. No initial work required today. */
  start(): Promise<void>;
  /** Tear down all timers. Idempotent. */
  stop(): void;
  /** Read the current snapshot (cloned). */
  current(): LoginSnapshot;
  /**
   * Probe `getMyselfInfo`, transition snapshot accordingly, and attach the periodic health check.
   * Network failures keep the current status (transient) and are logged at warn.
   */
  reportAccountInfo(): Promise<void>;
  /** Mark the session as logged-out due to upstream session invalidation. */
  handleAuthLost(): Promise<void>;
  /** Mark the session as logged-out for a specific reason. */
  reportLoggedOut(reasonKey?: LoginStatusMsgKey): void;
  /**
   * Begin a fresh QR-login session. Internally:
   * 1. Fetches a QR url + qrcodeKey from the API.
   * 2. Asks the caller to render the QR url to a base64 data URL (UI concern).
   * 3. Drives polling at 1Hz; on success persists cookies and probes account info.
   * 4. Auto-times-out after 3 minutes.
   */
  beginLogin(renderQr?: (url: string) => Promise<string>): Promise<void>;
  /**
   * Run a single QR-status poll. On success, the cookie save handshake runs
   * and `reportAccountInfo` is invoked, transitioning to LOGGED_IN.
   */
  private pollOnce;
  private reportLoggedIn;
  private reportLoginCheck;
  private reportTransientFailure;
  private reportQrReady;
  private reportQrPending;
  private reportQrFailure;
  /** Emit only when (status, msg, data) changes. */
  private transition;
  /**
   * 热替换登录健康检查间隔。adapter 在 dashboard 编辑 `app.healthCheckMinutes`
   * 后调用,会 dispose 旧定时器并按新间隔重 arm。`<=0` 等价于关闭健康检查。
   */
  setHealthCheckMs(ms: number): void;
  private attachHealthCheck;
  private detachHealthCheck;
  private runHealthCheck;
  private clearLoginTimer;
  /**
   * P2:轮询终态(86038 失效 / code 0 成功 / genericLoginFail)应同时清掉
   * 3min 过期 setTimeout。此前只 clearLoginTimer,过期定时器泄漏挂到 expiry
   * 才空跑一次 no-op(`if (!this.loginTimer) return`),其间持有闭包。
   */
  private clearLoginTimers;
  private clearLoginExpiryTimer;
}
/** Re-exported constant for adapter-side rate limiting; matches the legacy core debounce. */
declare const LOGIN_FLOW_AUTH_LOST_NOTIFY_DEBOUNCE_MS = 60000;
//#endregion
export { BACookie, BiliDataServer, BiliLoginStatus, BiliTicket, BilibiliAPI, type BilibiliAPIConfig, CreateGroup, GroupList, LOGIN_FLOW_AUTH_LOST_NOTIFY_DEBOUNCE_MS, LiveRoomInfo, LoginFlow, type LoginFlowOptions, type LoginPollResult, type LoginSnapshot, type LoginStatusMsgKey, MasterInfoData, MySelfInfoData, Result, UserCard, UserCardInfo, UserCardInfoData, UserCardSpace, V_VoucherCaptchaData, ValidateCaptchaData };
